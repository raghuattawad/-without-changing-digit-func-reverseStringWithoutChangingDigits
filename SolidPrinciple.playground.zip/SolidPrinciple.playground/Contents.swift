import UIKit

var greeting = "Hello, playground"


// without changing digit
func reverseStringWithoutChangingDigits(_ input: String) -> String {
    var reversed = Array(input)
    var left = 0
    var right = reversed.count - 1

    while left < right {
        if !reversed[left].isNumber {
            let temp = reversed[left]
            reversed[left] = reversed[right]
            reversed[right] = temp
            left += 1
            right -= 1
        } else {
            right -= 1
        }
    }

    return String(reversed)
}

let inputString = "abc12de3f"
let reversedString = reverseStringWithoutChangingDigits(inputString)
print(reversedString)  // Output: "f3e12dbca"
